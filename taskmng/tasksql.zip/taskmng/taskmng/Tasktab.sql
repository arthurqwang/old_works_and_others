/* Microsoft SQL Server - Scripting			*/
/* Server: DS_SERVER					*/
/* Database: taskview					*/
/* Creation Date 99-5-4 13:45:15 			*/

/****** Object:  Table dbo.dept_def    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.dept_def') and sysstat & 0xf = 3)
	drop table dbo.dept_def
GO

/****** Object:  Table dbo.env_var    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.env_var') and sysstat & 0xf = 3)
	drop table dbo.env_var
GO

/****** Object:  Table dbo.log_rec    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.log_rec') and sysstat & 0xf = 3)
	drop table dbo.log_rec
GO

/****** Object:  Table dbo.login    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.login') and sysstat & 0xf = 3)
	drop table dbo.login
GO

/****** Object:  Table dbo.rem    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.rem') and sysstat & 0xf = 3)
	drop table dbo.rem
GO

/****** Object:  Table dbo.t_runtime    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.t_runtime') and sysstat & 0xf = 3)
	drop table dbo.t_runtime
GO

/****** Object:  Table dbo.task_arch    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.task_arch') and sysstat & 0xf = 3)
	drop table dbo.task_arch
GO

/****** Object:  Table dbo.task_def    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.task_def') and sysstat & 0xf = 3)
	drop table dbo.task_def
GO

/****** Object:  Table dbo.task_exe    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.task_exe') and sysstat & 0xf = 3)
	drop table dbo.task_exe
GO

/****** Object:  Table dbo.user_def    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.user_def') and sysstat & 0xf = 3)
	drop table dbo.user_def
GO

/****** Object:  Default dbo.Dflt_login_last_modified    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.Dflt_login_last_modified') and sysstat & 0xf = 6)
	drop default dbo.Dflt_login_last_modified
GO

/****** Object:  Default dbo.UW_ZeroDefault    Script Date: 99-5-4 13:45:16 ******/
if exists (select * from sysobjects where id = object_id('dbo.UW_ZeroDefault') and sysstat & 0xf = 6)
	drop default dbo.UW_ZeroDefault
GO

/****** Object:  Default dbo.Dflt_login_last_modified    Script Date: 99-5-4 13:45:16 ******/
CREATE DEFAULT Dflt_login_last_modified AS getdate()
GO

/****** Object:  Default dbo.UW_ZeroDefault    Script Date: 99-5-4 13:45:16 ******/
CREATE DEFAULT UW_ZeroDefault AS 0
GO

/****** Object:  Table dbo.dept_def    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.dept_def (
	dept_no char (10) NOT NULL ,
	dept_name char (40) NOT NULL ,
	father_dept_no char (10) NULL ,
	constraint uni_dept unique(dept_no),
 	constraint pri_dept primary key(dept_no)
)
GO

/****** Object:  Table dbo.env_var    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.env_var (
	var_name char (20) NOT NULL ,
	var_value char (10) NOT NULL ,
	var_exp char (100) NOT NULL ,
	constraint uni_var unique(var_name),
 	constraint pri_var primary key(var_name)
)
GO

/****** Object:  Table dbo.log_rec    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.log_rec (
	user_id char (20) NOT NULL ,
	ip_address char (20) NOT NULL ,
	log_time datetime NOT NULL 
)
GO

/****** Object:  Table dbo.login    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.login (
	user_id char (20) NOT NULL ,
	ip_address char (20) NOT NULL ,
	last_modified datetime NOT NULL 
)
GO

setuser 'dbo'
GO

EXEC sp_bindefault 'dbo.Dflt_login_last_modified', 'login.last_modified'
GO

setuser
GO

/****** Object:  Table dbo.rem    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.rem (
	rem_no float NOT NULL ,
	user_id char (20) NOT NULL ,
	rem_title char (50) NOT NULL ,
	rem_cont text NOT NULL ,
	rem_cre_time datetime NOT NULL ,
	ʱ����� timestamp NOT NULL ,
	constraint uni_rem unique(rem_no)
)
GO

/****** Object:  Table dbo.t_runtime    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.t_runtime (
	r_stat char (30) NOT NULL ,
	task_id int NOT NULL ,
	r_cont text NOT NULL ,
	r_createtime datetime NOT NULL ,
	r_creater_id char (20) NOT NULL ,
	r_cont_type int NOT NULL ,
	ʱ����� timestamp NOT NULL
)
GO

/****** Object:  Table dbo.task_arch    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.task_arch (
	task_id int NOT NULL ,
	task_name char (100) NOT NULL ,
	task_create_time datetime NOT NULL ,
	task_end_time datetime NULL ,
	task_limit_time char (20) NULL ,
	task_creater char (20) NOT NULL ,
	task_proxy char (20) NULL ,
	task_father_id int NULL ,
	task_dept char (40) NOT NULL ,
	task_secu int NOT NULL ,
	task_exe char (200) NOT NULL ,
	exe_proced text NULL ,
	task_cont text NULL ,
	talk_name char (200) NULL ,
	ʱ����� timestamp NOT NULL ,
	constraint uni_task_arch unique(task_id),
 	constraint pri_task_arch primary key(task_id)

)
GO

/****** Object:  Table dbo.task_def    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.task_def (
	task_id int NOT NULL ,
	task_name char (100) NOT NULL ,
	task_cont text NULL ,
	task_create_time datetime NOT NULL ,
	task_end_time datetime NULL ,
	task_limit_time char (30) NULL ,
	task_creater_id char (20) NOT NULL ,
	task_proxy_id char (20) NULL ,
	task_father_id int NULL ,
	task_dept_id char (10) NOT NULL ,
	task_secu int NULL ,
	ʱ����� timestamp NOT NULL ,
	constraint uni_task_def unique(task_id),
 	constraint pri_task_def primary key(task_id)
)
GO

/****** Object:  Table dbo.task_exe    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.task_exe (
	task_id int NOT NULL ,
	exe_user_id char (20) NULL ,
	task_grade int NULL ,
	task_read bit NOT NULL ,
	limit_value int NULL ,
	talk_id char (20) NULL 
)
GO

setuser 'dbo'
GO

EXEC sp_bindefault 'dbo.UW_ZeroDefault', 'task_exe.task_read'
GO

setuser
GO

/****** Object:  Table dbo.user_def    Script Date: 99-5-4 13:45:16 ******/
CREATE TABLE dbo.user_def (
	user_id char (20) NOT NULL ,
	user_pass char (20) NOT NULL ,
	user_name char (10) NOT NULL ,
	dept_no char (10) NULL ,
	user_title char (30) NULL ,
	user_perm int NULL ,
	user_leader_id char (20) NULL ,
	user_email char (40) NULL ,
	user_tel char (40) NULL ,
	user_url char (40) NULL ,
	user_work text NOT NULL ,
	ʱ����� timestamp NOT NULL ,
	constraint uni_user_def unique(user_id),
 	constraint pri_user_def primary key(user_id)
)
GO
/*���뻷������*/
insert into dbo.env_var(
	var_name ,var_value,var_exp)
	values("maxid","0","��ǰ��������ֵ")
go
insert into dbo.env_var(
	var_name ,var_value,var_exp)
	values("var_timeout","15","������ʱʱ�䣨���ӣ�")
go



