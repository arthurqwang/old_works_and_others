{\rtf1\ansi\ansicpg936\deff0\deflang1033\deflangfe2052{\fonttbl {\f0\fnil\fcharset134 \'cb\'ce\'cc\'e5;}{\f1\fswiss\fprq7\fcharset0 Arial;}}
\uc1\pard\lang2052\ulnone\f0\fs20 /*\'b2\'e5\'c8\'eb\'b5\'a5\'ce\'bb\'b4\'fa\'c2\'eb\'d0\'c5\'cf\'a2*/\par
insert into dept_def(\par
\tab dept_no,dept_name,father_dept_no)\par
\tab values(\par
\tab "01","\'ce\'ef\'cc\'bd\'b9\'ab\'cb\'be","0")\par
go\par
insert into dept_def(\par
\tab dept_no,dept_name,father_dept_no)\par
\tab values(\par
\tab "001","\'d0\'c5\'cf\'a2\'d6\'d0\'d0\'c4","01")\par
go\par
\lang1033\f1 /*\lang2052\f0\'b2\'e5\'c8\'eb\'d3\'c3\'bb\'a7\'d0\'c5\'cf\'a2,\'b9\'dc\'c0\'ed\'d4\'b1\'ca\'c7\'b1\'d8\'d0\'eb\'b5\'c4*/\par
insert into dbo.user_def (\par
\tab user_id,user_pass,user_name,dept_no,\par
\tab user_title,user_perm,user_leader_id,user_email,user_work)\par
\tab values("admin","admin","\'b9\'dc\'c0\'ed\'d4\'b1","0\lang1033\f1 1\lang2052\f0 ",\par
"\'b9\'dc\'c0\'ed\'d4\'b1",1,"0","admin@mail_address","\'b8\'ba\'d4\'f0\'b1\'be\'cf\'b5\'cd\'b3\'b5\'c4\'c8\'ab\'c3\'e6\'b9\'dc\'c0\'ed")\par
go\par
\par
\par
}
 